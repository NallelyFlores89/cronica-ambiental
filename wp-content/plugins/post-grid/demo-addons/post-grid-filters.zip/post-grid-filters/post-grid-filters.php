<?php
/*
Plugin Name: Post Grid filters
Plugin URI: http://paratheme.com/
Description: Demo Addon for "Post Grid"
Version: 1.0.0
Author: paratheme
Author URI: http://paratheme.com
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Copyright: 	2015 ParaTheme

*/

if ( ! defined('ABSPATH')) exit;  // if direct access 


class PostGridFilters{
	
	public function __construct(){

		
		add_filter('post_grid_filter_title', array( $this, 'post_grid_filter_title_extra' ));
		add_filter('post_grid_filter_content', array( $this, 'post_grid_filter_title_extra' ));	
		add_filter('post_grid_filter_meta', array( $this, 'post_grid_filter_title_extra' ));			
		add_filter('post_grid_filter_social', array( $this, 'post_grid_filter_title_extra' ));			
		add_filter('post_grid_filter_hover', array( $this, 'post_grid_filter_title_extra' ));		
		add_filter('post_grid_filter_thumb', array( $this, 'post_grid_filter_title_extra' ));		
		
		}
		

	public function post_grid_filter_title_extra($extra)
		{
			return '♣ '.$extra.' ♥';
		}





	}
	
	new PostGridFilters();